## React + TypeScript Portfolio

- This is the version of my react js portfolio converted into React TypeScript